import time


from selenium import webdriver



from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support.ui import Select
from selenium.webdriver.remote.command import Command
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.actions.key_actions import *
from selenium.webdriver.common.alert import Alert
from msedge.selenium_tools import Edge
import os

from webdriver_manager.chrome import ChromeDriverManager
from webdriver_manager.microsoft import IEDriverManager, EdgeChromiumDriverManager

from pageobject.TypeDeclaration import check_element_property, IdentifierType


class Browser:

    def __init__(self):
        pass

    def initialize_driver(self, browser_type):
        self.driver = webdriver.Edge(r"C:\Users\DELL\PycharmProjects\msedgedriver.exe")



    def go_to(self, app_url):

        try:
            self.driver.get(app_url)
        except Exception as e:
            print(e)

    def find_element(self, in_element_property):
        _ele = None
        element_property_values = check_element_property(in_element_property)
        identifier_type = element_property_values[0]
        element_property = element_property_values[1]
        try:
            if identifier_type == IdentifierType.id:
                _ele = self._wait.until(EC.presence_of_element_located((By.ID, element_property)))
            elif identifier_type == IdentifierType.name:
                _ele = self._wait.until(EC.presence_of_element_located((By.NAME, element_property)))
            elif identifier_type == IdentifierType.link_text:
                _ele = self._wait.until(EC.presence_of_element_located((By.LINK_TEXT, element_property)))
            elif identifier_type == IdentifierType.class_name:
                _ele = self._wait.until(EC.presence_of_element_located((By.CLASS_NAME, element_property)))
            elif identifier_type == IdentifierType.css_selector:
                _ele = self._wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, element_property)))
            elif identifier_type == IdentifierType.xpath:
                self.driver.execute(Command.STATUS)
                _ele = self._wait.until(EC.presence_of_element_located((By.XPATH, element_property)))
            else:
                print("Error in find element")
            return _ele
        except Exception as e:
            print("Exception in find element " + e)
            return None

    def find_elements(self, in_element_property):

        element_property_values = check_element_property(in_element_property)
        identifier_type = element_property_values[0]
        element_property = element_property_values[1]
        try:
            if identifier_type == IdentifierType.id:
                self._elements =  self.driver.find_elements_by_id(element_property)
            elif identifier_type == IdentifierType.name:
                self._elements = self.driver.find_elements_by_name(element_property)
            elif identifier_type == IdentifierType.link_text:
                self._elements = self.driver.find_elements_by_link_text(element_property)
            elif identifier_type == IdentifierType.class_name:
                self._elements = self.driver.find_elements_by_class_name(element_property)
            elif identifier_type == IdentifierType.css_selector:
                self._elements = self.driver.find_elements_by_css_selector(element_property)
            elif identifier_type == IdentifierType.xpath:
                self.driver.execute(Command.STATUS)
                self._elements = self.driver.find_elements_by_xpath(element_property)
            else:
                print("error in find elements")
            return self._elements
        except Exception as e:
            print("error in find elements "+ e)
            return None

    def _find_element(self,in_element_property):
        self._element = self.find_element(in_element_property)
        return self._element

    def click_element(self,in_element_property):

        try:
            self._find_element(in_element_property)
            if self._element is not None:
                self._element.click()
                self._element = None
                return True
        except Exception as e:
            print("failure in click element " + "e")

    def set_text(self, in_element_property, input_text):
        try:
            self._find_element(in_element_property)
            self._element.clear()
            self._element.send_keys(input_text)
            self._element = None
            return  True
        except Exception as e:
            print("Error in set text " + e)
            return False

    def clear_text(self, in_element_property, input_text):
        try:
            self._find_element(in_element_property)
            self._element.clear()
            self._element = None
            return True
        except Exception as e:
            print("Error in set text " + e)
            return False

    def switch_to_window(self, window_id = None):
        if window_id is not None:
            self.driver.switch_to_window(window_id)
            return window_id
        else:
            current_window = self.current_window()
            all_windows = self.all_opened_windows()
            for window in all_windows:
                if window == current_window:
                    self.driver.switch_to_window(window)
                    return window

    def current_window(self):
        return (self.driver.current_window_handle)

    def all_opened_windows(self):
        return(self.driver.window_handles)












