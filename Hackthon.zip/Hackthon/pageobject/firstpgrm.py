from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time
# driver = webdriver.Edge(r"C:\Users\DELL\PycharmProjects\msedgedriver.exe")
driver = webdriver.chrome(r"C:\Users\DELL\PycharmProjects\chromedriver-116.exe")
driver.get("https://www.google.com/")
driver.maximize_window()
driver.find_element_by_name("q").send_keys("LinkedIn login")
driver.find_element_by_name("q").send_keys(Keys.ENTER)
# driver.find_element_by_partial_link_text("LinkedIn Login").click()
# driver.find_element_by_id("username").send_keys("enter your username")
# driver.find_element_by_id("password").send_keys("enter your password”)
# driver.find_element_by_tag_name("button").click()
# time.sleep(5)
print(driver.title)
print(driver.current_url)

from selenium import webdriver
# Just Run this to execute the below script
if __name__ == '__main__':
   # Instantiate the webdriver with the executable location of MS Edge web driver
   browser = webdriver.Edge(r"C:\Users\DELL\PycharmProjects\msedgedriver.exe")
   # Simply just open a new Edge browser and go to lambdatest.com
   browser.get('https://www.lambdatest.com')