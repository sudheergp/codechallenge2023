import os
from enum import Enum, auto

from selenium.webdriver.chrome.options import Options as ChromeOption
from msedge.selenium_tools import EdgeOptions as EdgeOption

class IdentifierType(Enum):
    id = auto()
    name = auto()
    class_name = auto()
    css_selector = auto()
    xpath = auto()
    link_text = auto()

def desired_capbilities_chrome(input_option = None):
    _chrome_options = ChromeOption()
    # if input_options.upper() = "HEADLESS" or platform.system()


def check_element_property(element_property):

    property_list = ((element_property).strip()).split('_')
    print(property_list)

    e_identification = property_list[0]
    e_property = '_'.join(property_list[1:])
    element_property_list = {
        "ID" : IdentifierType.id,
        "NAME" : IdentifierType.name,
        "CSSSELECTOR": IdentifierType.css_selector,
        "XPATH":IdentifierType.xpath,
        "LINKTEXT":IdentifierType.link_text,
        "CLASSNAME": IdentifierType.class_name,
        }
    if e_identification.upper() in element_property_list.keys():
        identifier_type = element_property_list[e_identification.upper()]
        return [identifier_type,e_property]
    else:
        print("Not present")
